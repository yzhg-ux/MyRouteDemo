package com.yzhg.mvvm.http;

/**
 * 类 名: ApiService
 * 作 者: yzhg
 * 创 建: 2019/4/11 0011
 * 版 本: 1.0
 * 历 史: (版本) 作者 时间 注释
 * 描 述:
 */
public interface ApiService {

    String jokeUrl = "http://api.djapi.cn/joke/get";
    //获取图片
    String PictureUrl = "https://api.apiopen.top/getImages";

}
