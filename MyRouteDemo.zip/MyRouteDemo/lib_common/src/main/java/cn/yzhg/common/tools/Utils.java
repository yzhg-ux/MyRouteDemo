package cn.yzhg.common.tools;

import android.annotation.SuppressLint;
import android.content.Context;

/**
 * 类 名: Utils
 * 作 者: yzhg
 * 创 建: 2018/9/17 0017
 * 版 本: 1.0
 * 历 史: (版本) 作者 时间 注释
 * 描 述:
 */
public class Utils {

    @SuppressLint("StaticFieldLeak")
    private static Context context;

    private Utils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    public static void init(Context context) {
        Utils.context = context;
    }

    public static Context getContext() {
        if (context != null) return context;
        throw new NullPointerException("请在Application中初始化操作");
    }


}
