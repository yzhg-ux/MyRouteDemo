package cn.yzhg.common.constant;

/**
 * 类 名: Constant
 * 作 者: yzhg
 * 创 建: 2019/4/2 0002
 * 版 本: 1.0
 * 历 史: (版本) 作者 时间 注释
 * 描 述:
 */
public class Constant {

    public static final String AROUTER_ACTIVITY_MVVM = "/mvvm/MVVMActivity";

    //网络请求时长
    public static final int DEFAULT_TIMEOUT = 60000;

    //true  为线上版本   false为测试版
    public static final boolean DEBUG = true;
}
