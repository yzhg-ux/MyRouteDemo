package cn.yzhg.common.base.ui;

/**
 * 类 名: NetStateEnum
 * 作 者: yzhg
 * 创 建: 2019/4/11 0011
 * 版 本: 1.0
 * 历 史: (版本) 作者 时间 注释
 * 描 述:
 */
public enum NetStateEnum {

    SUCCESS,

    FAILED,

    EMPTY
}
