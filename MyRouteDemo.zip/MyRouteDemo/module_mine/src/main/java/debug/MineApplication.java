package debug;

import cn.yzhg.common.application.BaseApplication;

/**
 * 类 名: MineApplication
 * 作 者: yzhg
 * 创 建: 2018/9/18 0018
 * 版 本: 1.0
 * 历 史: (版本) 作者 时间 注释
 * 描 述:
 */
public class MineApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
