package cn.yzhg.main;

import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;

import com.alibaba.android.arouter.launcher.ARouter;

import butterknife.ButterKnife;

public class Main2Activity extends AppCompatActivity {

    private FrameLayout mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = item -> {
        int id = item.getItemId();
        if (id == R.id.navigation_home) {
            /*
             * 作 者: yzhg
             * 历 史: (版本) 1.0
             * 描 述: 找到homeFragment
             */
            Fragment fragment = (Fragment) ARouter.getInstance().build("/home/HomeFragment").navigation();
            FragmentManager supportFragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = supportFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.message, fragment);
            fragmentTransaction.commit();
            return true;
        } else if (id == R.id.navigation_dashboard) {
            Fragment fragment = (Fragment) ARouter.getInstance().build("/shop/ShopFragment").navigation();
            FragmentManager supportFragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = supportFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.message, fragment);
            fragmentTransaction.commit();
            return true;
        } else if (id == R.id.navigation_notifications) {
            Fragment fragment = (Fragment) ARouter.getInstance().build("/mine/MineFragment").navigation();
            FragmentManager supportFragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = supportFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.message, fragment);
            fragmentTransaction.commit();
            return true;
        }
        return false;
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ButterKnife.bind(this);

        mTextMessage = findViewById(R.id.message);
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Fragment fragment = (Fragment) ARouter.getInstance().build("/home/HomeFragment").navigation();
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = supportFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.message, fragment);
        fragmentTransaction.commit();
    }
}
